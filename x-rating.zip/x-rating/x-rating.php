<?php
/*
* Plugin Name: X-Rating
* Description: This is Bootstrap based rating plugin. Lightweight and multiple icon options. 
* Plugin URI: http://www.xitclub.biz
* Author: Mian Shahzad Raza
* Author URI: http://www.mianshahzadraza.com
* Version: 1.0.0
*/
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

//Create Custom Table For Plugin
function create_rating_table(){
	global $wpdb;
	$table_name = $wpdb->prefix . "ratings";
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  user_id varchar(255) NOT NULL,
	  post_id varchar(255) NOT NULL,
	  rating_value varchar(255) DEFAULT '' NOT NULL,
	  time timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	  UNIQUE KEY id (id)
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
register_activation_hook(__FILE__, 'create_rating_table');

//Scripts & Styles
function xrating_plugin_styles() {

		wp_register_style( 'bootstrap_css',  '//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css' );
        wp_enqueue_style( 'bootstrap_css' );

        wp_register_style( 'bootstrap_rating_css',  plugin_dir_url( __FILE__ ) . 'assets/css/bootstrap-rating.css' );
        wp_enqueue_style( 'bootstrap_rating_css' );

        wp_enqueue_script( 'bootstrap_rating_js',  plugin_dir_url( __FILE__ ) . 'assets/js/bootstrap-rating.min.js', array('jquery'), '', true );
	
		wp_enqueue_script( 'xrating_plugin_js',  plugin_dir_url( __FILE__ ) . 'assets/js/set_rating.js', array('jquery'), '', true );

		wp_localize_script( 'xrating_plugin_js', 'xrating', array(
			'ajax_url' => admin_url( 'admin-ajax.php' )
		));

}
add_action( 'wp_enqueue_scripts', 'xrating_plugin_styles' );

add_action( 'wp_ajax_nopriv_store_rating', 'store_rating' );
add_action( 'wp_ajax_store_rating', 'store_rating' );
function store_rating(){
	
	global $wpdb;
	$table_name = $wpdb->prefix . "ratings";

	$user_id = $_POST['user_id'];
	$post_id = $_POST['post_id'];
	$rating = $_POST['rate_val'];

	if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) { 
		if($user_id ==0 || $user_id ==""){
			echo "You Must Be Logged-in to Rate";
			die();
		}
		else {
			$check_rating = $wpdb->get_row("SELECT * FROM $table_name WHERE user_id = $user_id AND post_id = $post_id");
			if($check_rating) {
				echo "Sorry, You Already Rated For This Post!";
				die();
			}
			else {
				$sql = $wpdb->insert(
					''.$table_name.'',
					array(
						'user_id' => $user_id,
						'post_id' => $post_id,
						'rating_value' => $rating
					)
				);
				if($sql) {
					echo "Thank You For Rating!";
					die();
				}
				else {
					echo "Error, Try Later";
					die();
				}	
			}
			
			
		}
		
	}
	else {
		wp_redirect( get_permalink( $_REQUEST['post_id'] ) );
		exit();
	}
	
}
function get_rating($postID){
	$id = $postID;
    global $wpdb;
	$ratings = $wpdb->get_results( "SELECT user_id, rating_value FROM `{$wpdb->prefix}ratings` WHERE post_id ='$id'" );
	$by_users = $wpdb->get_var( "SELECT COUNT(*) FROM `{$wpdb->prefix}ratings` WHERE post_id ='$id'" );
	$sum_ratings = 0;
	if($by_users != "" && $by_users>0) {
		foreach ($ratings as $row) {
			$sum_ratings+= $row->rating_value;
		}
		$stars = $sum_ratings/$by_users;
		echo $stars;
	}
	else {
		echo "0";
	}
}
function display_rating($content){ ?>

<div class="row text-right" style="font-size:36px;">
	<input type="hidden" class="rating" id="rating" value="<?php get_rating(get_the_ID()) ?>" onchange="setRating(<?php the_ID(); ?>,<?php echo get_current_user_id(); ?>);"/>
</div>
<div class="row text-right" style="font-size:28px;">
	<span id="response"></span>
</div>
<?php }
add_shortcode('XRATING', 'display_rating');

?>