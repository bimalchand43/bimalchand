function setRating(id,usr) {
	
	var postID = id;
	var usrID = usr;
	var ratval = jQuery("#rating").val();
	jQuery.ajax({
		url : xrating.ajax_url,
		type : 'post',
		data : {
			action : 'store_rating',
			rate_val : ratval,
			user_id : usrID,
			post_id : postID
		},
		success : function( response ) {
				jQuery('#response').html( response );
		}
	});
}
