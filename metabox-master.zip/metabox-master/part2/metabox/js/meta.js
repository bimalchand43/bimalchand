jQuery(document).ready(function($){
	
	$('#color__picker').wpColorPicker();
	$('#date__picker').datepicker();
	quicktags({
			id: "__quictags",
			buttons: "link,strong,em"
			
		
		
	});
});