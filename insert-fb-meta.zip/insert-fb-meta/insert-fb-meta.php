<?php
/*
* Plugin Name: Insert FB Meta
* Description: This plugin will insert Facebook meta data in header
* Plugin URI: http://www.xitclub.biz
* Author: Mian Shahzad Raza
* Author URI: http://www.mianshahzadraza.com
* Version: 1.0.0
*/
?>
<?php

add_action('wp_head','display_opengraph');

function display_opengraph() { 
	if(is_single()) {
	?>
	<meta property="og:title" content="<?php the_title() ?>"/>
	<meta property="og:url" content="<?php the_permalink() ?>"/>
	<meta property="og:description" content="<?php the_excerpt() ?>" />
	<meta property="og:site_name" content="<?php bloginfo('name') ?>"/>
	<?php 
	if( has_post_thumbnail() ) {
	$image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' ); 
	?>
	<meta property="og:image" content="<?php echo $image[0] ?>"/>
	<?php } else {?>
	<meta property="og:image" content="<?php echo esc_attr( get_option('default-image-url') ) ?>"/>
<?php } } } 

//Plugin Settings Page
add_action('admin_menu','my_plugin_settings');
function my_plugin_settings(){
	add_menu_page('FB Meta Plugin', 
				  'My Meta Data', 
				  'administrator', 
				  'insert-my-meta', 
				  'my_plugin_settings_page', 
				  'dashicons-facebook-alt', 
				  '90'
				);
}
add_action('admin_init','my_plugin_options');
function my_plugin_options() {
	register_setting('meta-deta-group','active-meta-deta');
	register_setting('meta-deta-group','default-image-url');
}
function my_plugin_settings_page(){ ?>
	<div class="wrap" id="my-fb-meta">
		<form action="options.php" method="post">
		<?php settings_fields( 'meta-deta-group' ); ?>
    	<?php do_settings_sections( 'meta-deta-group' ); ?>
		<label>Default Image URL</label>
		<input type="text" name="default-image-url" value="<?php echo esc_attr( get_option('default-image-url') ) ?>">
		<?php submit_button() ?>
		</form>
	</div>
<?php } ?>

<?php 
//Scripts & Styles
function load_custom_plugin_scripts() {
        wp_register_style( 'custom_plugin_css',  plugin_dir_url( __FILE__ ) . 'assets/css/main.css', false, '1.0.0' );
        wp_enqueue_style( 'custom_plugin_css' );
}
add_action( 'admin_enqueue_scripts', 'load_custom_plugin_scripts' );
add_action( 'wp_enqueue_scripts', 'load_custom_plugin_scripts' );

function load_custom_plugin_js(){
	wp_enqueue_script( 'custom_plugin_js',  plugin_dir_url( __FILE__ ) . 'assets/js/my-script.js', '', '', true );
}
add_action( 'wp_enqueue_scripts', 'load_custom_plugin_js' );
?>
